<?php
header("Location: index.html", true, 301);
exit; 
?>